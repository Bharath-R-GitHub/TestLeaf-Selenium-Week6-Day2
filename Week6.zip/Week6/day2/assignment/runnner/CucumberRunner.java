package week6.day2.assignment.runnner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/week6/day2/assignment/features", glue = { "week6/day2/assignment/steps",
		"week6/day2/assignment/hooks" }, monochrome = true, publish = true, tags = "@smoke or @sanity")
public class CucumberRunner extends AbstractTestNGCucumberTests {

}
