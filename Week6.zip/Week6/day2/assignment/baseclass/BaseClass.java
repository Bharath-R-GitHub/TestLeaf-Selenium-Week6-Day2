package week6.day2.assignment.baseclass;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	public static ChromeDriver driver;
}
