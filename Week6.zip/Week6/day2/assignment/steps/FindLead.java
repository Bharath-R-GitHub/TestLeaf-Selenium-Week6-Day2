package week6.day2.assignment.steps;

import org.openqa.selenium.By;
import org.testng.Assert;

import BaseClass.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FindLead extends BaseClass {

	public String changedCompany;
	public String company;
	public String cmp;

	@Given("Enter the firstName as {string}")
	public void enterFirstName(String fName) {
		driver.findElement(
				By.xpath("//div[contains(@class,'x-tab-item')]/following-sibling::div/div/input[@name='firstName']"))
				.sendKeys(fName);
	}

	@Given("Change the company name to {string}")
	public void changeCompany(String chgCompany) {
		changedCompany = chgCompany;
		driver.findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).clear();
		driver.findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).sendKeys(chgCompany);
	}

	@Given("Click on Update")
	public void clickUpdate() throws InterruptedException {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
		Thread.sleep(2000);
	}

	@When("Get the company name")
	public void getCmpName() {
		cmp = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		company = cmp.substring(0, changedCompany.length());
	}

	@Then("Validate company name")
	public void validateCmpName() {
		Assert.assertEquals(company, changedCompany);
	}
}
