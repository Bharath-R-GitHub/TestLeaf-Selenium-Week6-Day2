package week6.day2.assignment.steps;

import org.openqa.selenium.By;

import BaseClass.BaseClass;
import io.cucumber.java.en.Given;

public class DuplicateLead extends BaseClass {

	@Given("Click on Duplicate Lead Button")
	public void duplicateLead() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
	}

	@Given("Enter new company as {string} and new name as {string}")
	public void duplicateLeadFields(String newCName, String newFName) {
		driver.findElement(By.id("createLeadForm_companyName")).clear();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(newCName);
		driver.findElement(By.id("createLeadForm_firstName")).clear();
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(newFName);
	}

}
