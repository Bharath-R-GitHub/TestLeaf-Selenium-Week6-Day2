package week6.day2.assignment.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import BaseClass.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass {

	@Given("Click on Create Lead Button")
	public void clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
	}

	@Given("Fill the details in the form with CompanyName as {string} and Enter FirstName as {string} and Enter LastName as {string}")
	public void createLead_1(String cName, String fName, String lName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	}

	@Given("Enter FirstNameLocal as {string} and Enter the Department as {string} and Enter the Description as {string}")
	public void createLead_2(String locFName, String dept, String desc) {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(locFName);
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(dept);
		driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);
	}

	@Given("Enter the Email as {string} and Enter the mobile number as {string} and Enter StateProvince as {string}")
	public void createLead_3(String email, String phoneNum, String state) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='createLeadForm_primaryPhoneNumber']")).sendKeys(phoneNum);
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);
	}

	@When("Click on Submit Button")
	public void submit() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("Validate resulting page")
	public void createLeadValidate() {
		String resultingPage = driver.getTitle();
		Assert.assertEquals(resultingPage, "View Lead | opentaps CRM");
	}

}
