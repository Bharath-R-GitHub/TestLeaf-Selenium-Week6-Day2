package week6.day2.assignment.steps;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;

import BaseClass.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteLead extends BaseClass {

	public String firstLeadID;

	@Given("Click on Find Leads Button")
	public void clickFindLead() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
	}

	@Given("Click on phone")
	public void clickPhone() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
	}

	@Given("Enter phone number as {string}")
	public void getPhoneNumber(String phoneNum) {
		driver.findElement(By.name("phoneNumber")).sendKeys(phoneNum);
	}

	@Given("Click on Find Lead")
	public void findLead() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}

	@Given("Capture First resulting Lead")
	public void captureLead() throws InterruptedException {
		firstLeadID = driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]")).getText();
		System.out.println("The First Lead ID is " + firstLeadID);
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]")).click();
	}

	@Given("Click on Delete Lead")
	public void deleteLead() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
	}

	@Given("Enter captured Lead")
	public void capturedLead() {
		driver.findElement(By.xpath("//div[@class='x-form-element']/input[@name='id']")).sendKeys(firstLeadID);
	}

	@When("Click on Find Lead Button")
	public void searchLead() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}

	@Then("Validate Lead")
	public void validateLead() {
		String verify = driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText();
		assertEquals(verify, "No records to display");
	}

}
