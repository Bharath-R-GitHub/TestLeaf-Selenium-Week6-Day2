package week6.day2.assignment.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import BaseClass.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class EditLead extends BaseClass {

	@Given("Enter the Email as {string} and Enter StateProvince as {string}")
	public void editLead(String email, String state) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);
	}

	@Given("Click on Edit Button")
	public void clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
	}

	@Given("Clear the Description Field and fill ImportantNote Field as {string}")
	public void editField(String note) {
		driver.findElement(By.id("updateLeadForm_description")).clear();
		driver.findElement(By.id("updateLeadForm_importantNote")).sendKeys(note);
	}

	@When("Click on Update Button")
	public void clickUpdateButton() {
		driver.findElement(By.className("smallSubmit")).click();
	}

}
